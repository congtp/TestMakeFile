#!/usr/bin/zsh
rm -rf build
mkdir -p build
cd build